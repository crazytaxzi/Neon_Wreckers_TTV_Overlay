# Neon Wreckers: Station Zero 2.0

Neon Wreckers is a server-authoritative, mobile-first stream game. Version 2.0 Sprint 1 stabilizes the existing game without redesigning its interface, changing artwork, altering mechanics, or changing effective balance values.

The repository has one production path: `compose.yaml` builds one application image and one gateway image from the root `Dockerfile`. Nginx serves the player app at `/`, the control center at `/admin/`, the OBS overlay at `/overlay/`, and the API plus WebSockets at `/api/`.

## Repository map

- `apps/` contains the player web app, admin app, overlay, API, and worker.
- `packages/` contains deterministic game rules, the validated content loader, browser helpers, shared styling, and external-service adapters.
- `content/` contains versioned, validated game content and balance configuration.
- `assets/` contains the canonical visual-key manifest.
- `infrastructure/` contains Prisma, SQL migrations, and the single gateway configuration.
- `scripts/` contains the supported install, update, backup, restore, and verification processes.
- `tools/` contains deterministic content, dependency, migration, route, and repository quality gates.
- `docs/` contains architecture, deployment, development, administration, overlay, dependency, and test documentation.

## Production installation

```bash
cp .env.example .env
chmod 600 .env
# Replace every example value in .env.
sudo bash scripts/install.sh
```

The installer validates configuration, installs Docker and Certbot when needed, obtains TLS, builds the images, starts the stack, and enables certificate-renewal and daily-backup timers. Full instructions are in [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md). Release-specific deployment evidence is in [docs/DEPLOYMENT_VERIFICATION.md](docs/DEPLOYMENT_VERIFICATION.md).

## Verification

```bash
bash scripts/verify.sh
```

Verification installs locked dependencies, runs game-engine, API/service, content, dependency, database, route, and repository checks, then builds integrations, the database seed, API, worker, web, admin, and overlay. Docker Compose and image builds run when a Docker daemon is available.

## Security notice

The imported pre-2.0 archive contained committed environment files with live-looking credentials. Those files are removed. Rotate every database, Redis, session, Twitch, StreamElements, and other credential that appeared in an earlier package before deployment.
