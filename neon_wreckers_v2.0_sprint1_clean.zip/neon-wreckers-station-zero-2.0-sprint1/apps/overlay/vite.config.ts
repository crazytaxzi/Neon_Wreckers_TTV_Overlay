import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  base: '/overlay/',
  server: {
    proxy: {
      '/api': 'http://127.0.0.1:8787'
    }
  },
  build: {
    sourcemap: false,
    cssCodeSplit: true,
    target: 'es2022'
  }
});
